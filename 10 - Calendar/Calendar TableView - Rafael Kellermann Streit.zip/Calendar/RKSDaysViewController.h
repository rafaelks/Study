//
//  RKSDaysViewController.h
//  Calendar
//
//  Created by Rafael Kellermann Streit on 1/8/14.
//  Copyright (c) 2014 Rafael Kellermann Streit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RKSDaysViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIView *viewWrapper;
@property (nonatomic, strong) NSDictionary *month;

@end
