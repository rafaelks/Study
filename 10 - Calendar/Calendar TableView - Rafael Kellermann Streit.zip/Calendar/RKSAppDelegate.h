//
//  RKSAppDelegate.h
//  Calendar
//
//  Created by Rafael Kellermann Streit on 1/7/14.
//  Copyright (c) 2014 Rafael Kellermann Streit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RKSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
