//
//  main.m
//  Calendar
//
//  Created by Rafael Kellermann Streit on 1/7/14.
//  Copyright (c) 2014 Rafael Kellermann Streit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RKSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RKSAppDelegate class]));
    }
}
